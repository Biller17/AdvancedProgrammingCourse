README blackjack server and client



Adrian Biller A01018940

This program consists on two c files, one server and one client.

First you must run blackJackServer.c with gcc blackJackServer.c -o server
the std=c99 flag is not necessary but is recommended.

Then blackJackClient.c must be compiled also using gcc blackJackClient.c -o client

After compiling both programs then server program must be called first in terminal with this command sudo ./server <number of the desired port>

After choosing the port then you can run the client program as follows sudo ./client <server address> <server port>

once done the client program will run and the game will start.






































ABA
























ABA
